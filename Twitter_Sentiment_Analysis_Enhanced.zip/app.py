import streamlit as st
import pandas as pd
import joblib
from sklearn.feature_extraction.text import CountVectorizer

# Load model and vectorizer
model = joblib.load("data/sentiment_model.pkl")
vectorizer = joblib.load("data/vectorizer.pkl")

st.title("Twitter Sentiment Analyzer")

text_input = st.text_area("Enter a tweet to analyze sentiment:")

if st.button("Analyze"):
    if text_input.strip() == "":
        st.warning("Please enter some text.")
    else:
        X = vectorizer.transform([text_input])
        prediction = model.predict(X)[0]
        sentiment = "Positive 😊" if prediction == 1 else "Negative 😞"
        st.success(f"Predicted Sentiment: {sentiment}")