# Enhanced Twitter Sentiment Analysis

This project analyzes the sentiment of tweets using a Naive Bayes classifier, enhanced with:

- 📊 Data visualization of sentiment distribution
- 🖥️ Streamlit web app for interactive sentiment analysis

## Features

- Sentiment classification using Sentiment140 dataset
- Visualizes sentiment distribution
- Streamlit app to analyze custom tweet input

## How to Run

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Train and save the model:
```
python save_model.py
```

3. Run Streamlit app:
```
streamlit run app.py
```