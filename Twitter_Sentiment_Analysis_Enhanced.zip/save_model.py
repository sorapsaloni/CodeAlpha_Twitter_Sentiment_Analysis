import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib

# Load data
df = pd.read_csv('data/sentiment140_sample.csv', encoding='latin-1', header=None)
df.columns = ['sentiment', 'id', 'date', 'query', 'user', 'text']
df = df[['sentiment', 'text']]
df['sentiment'] = df['sentiment'].apply(lambda x: 1 if x == 4 else 0)

# Features and labels
X = df['text']
y = df['sentiment']

# Vectorize
vectorizer = CountVectorizer(stop_words='english')
X_vect = vectorizer.fit_transform(X)

# Model
model = MultinomialNB()
model.fit(X_vect, y)

# Save model and vectorizer
joblib.dump(model, 'data/sentiment_model.pkl')
joblib.dump(vectorizer, 'data/vectorizer.pkl')